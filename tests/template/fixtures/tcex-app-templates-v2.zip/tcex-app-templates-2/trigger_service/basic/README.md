# Basic Service Trigger

## Release Notes

### 1.0.0

-   Initial Release

# Category

-   Service Trigger

# Service Configuration

**Example Service Input** *(TypeEnum.String)*

An example input to the Trigger at the service level.

# Inputs

**Example Trigger Input** *(TypeEnum.String)*

An example input to the Trigger at the playbook level.

# Outputs

-   example.date_time *(String)*
-   example.service_input *(String)*
-   example.trigger_input *(String)*
