# Egress Template

# Release Notes

### 1.0.0 (2021-04-22)

* Initial Release


# Description

A template for apps that export indicators from ThreatConnect into an external service.
