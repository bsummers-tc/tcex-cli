# Ingress Template using TcEx Batch

# Release Notes

### 1.0.0 (2021-04-22)

* Initial Release


# Description

A template of a working ingress Organization App.

### Inputs

  **ThreatConnect Owner** *(Choice)*
  The owner from which indicators (and maybe groups) will be counted
