"""Core Utils Module"""
