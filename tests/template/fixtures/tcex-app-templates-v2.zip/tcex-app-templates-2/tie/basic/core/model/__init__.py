"""Core model classes."""
