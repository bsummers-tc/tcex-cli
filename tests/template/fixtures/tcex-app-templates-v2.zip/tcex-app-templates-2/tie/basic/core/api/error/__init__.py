"""Core Error Module"""
