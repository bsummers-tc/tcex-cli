"""Core TcEx Module"""
