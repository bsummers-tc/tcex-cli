"""Core injectable middleware module."""
