"""API Endpoint Resources"""
