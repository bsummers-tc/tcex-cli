# Webhook

## Release Notes

### 1.0.0

-   Initial Release

# Category

-   Utility

# Description

The files in this parent template are common for all App types and is intended to be used as the base parent for most other templates.

# Service Configuration

**Example Service Input** *(TypeEnum.String)*

An example input to the Trigger at the service level.

# Inputs

**Example Trigger Input** *(TypeEnum.String)*

An example input to the Trigger at the playbook level.

# Outputs

-   headers *(String)*
-   method *(String)*
-   params *(String)*
