"""ThreatConnect Playbook App"""

import json

from tcex.app.playbook import Playbook

from service_app import ServiceApp


class App(ServiceApp):
    """Service App Template."""

    def webhook_event_callback(
        self,
        body: bytes | str,  # noqa: ARG002
        headers: list[dict[str, str]],
        method: str,
        params: list[dict[str, str]],
        playbook: Playbook,
        **kwargs,  # noqa: ARG002
    ):
        """Run the trigger logic.

        Args:
            body: The HTTP request body.
            headers: The HTTP request headers (multiple values will be returned in an array).
            method: The HTTP request method (e.g., DELETE, GET, etc.).
            params: The HTTP request query params (multiple values will be returned in an array).
            playbook: (object | kwargs) An instance of Playbook to use to write output variables.
                Not provided when feature WebhookServiceEndpoint is enabled.
            config (dict | kwargs): The playbook config inputs. Not provided
                when feature WebhookServiceEndpoint is enabled.
            request_key (str | kwargs): The unique request key for the current event. Only
                provided when feature webhookResponseMarshall or webhookServiceEndpoint is enabled.
            trigger_id (int | kwargs): The trigger id value used for the playbook being
                launched. Not provided when feature WebhookServiceEndpoint is enabled.
            **kwargs: Additional keyword arguments.

        Returns:
            bool, Callable[..., Any], dict: Dependent on the feature
                the method should provide different response.
        """
        response = None
        if self.tcex.app.install_json.has_feature('WebhookResponseMarshall'):
            # * Callable - Playbook will be launched and if marshall
            #              callback will be set to response.
            # * True - Playbook will be launched.
            # * Else - Playbook will NOT be launched.
            response = True
        elif self.tcex.app.install_json.has_feature('WebhookServiceEndpoint'):
            # * Dict - Playbook will be launched and provided data
            #          will be used in the response to the client.
            # * Else - Response will be set to default of statusCode=200, body=None, and headers=[].
            response = None
        else:
            # * Dict - Playbook will not be launched and provided data
            #          will be used in the response to the client.
            # * True - Playbook will be launched.
            # * Else - Playbook will NOT be launched.
            response = True

            # format headers and params for output variables (does not handle duplicate keys)
            headers_ = json.dumps([f"""{header['name']}={header['value']}""" for header in headers])
            params_ = json.dumps([f"""{param['name']}={param['value']}""" for param in params])

            # write output variables
            playbook.create.variable('headers', headers_, 'String')
            playbook.create.variable('method', method, 'String')
            playbook.create.variable('params', params_, 'String')

        return response

    def webhook_marshall_event_callback(
        self,
        body: bytes | str,
        headers: list[dict[str, str]],
        request_key: str,  # noqa: ARG002
        status_code: int,
        trigger_id: int,  # noqa: ARG002
    ):
        """Handle webhook marshall events.

        !!! Only needed when APP support WebhookResponseMarshall feature. !!!

        A marshall event contains the the body, headers, and status code from a completed
        Playbook. This call back method allows the service to update or change the response
        that for the HTTP request.

        Example Headers:

        "headers": [
            {
                "name": "Accept",
                "value": "*/*"
            }
        ]

        Args:
            body: The response body.
            headers: The response headers (multiple values will be returned in an array).
            request_key: [WebhookResponseMarshall] The unique request key for the current event.
            status_code: The response status code.
            trigger_id: Optional trigger_id value used in testing framework.

        Returns:
            bool: True if playbook should trigger, False if not.
        """
        return {
            'body': body,
            'headers': headers,
            'status_code': status_code,
        }
