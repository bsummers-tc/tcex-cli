# Example Basic Playbook App

## Release Notes

### 1.0.0

-   Initial Release

# Category

-   Utility

# Description

A template that provides the structure for a Playbook App without any App logic.

# Inputs
