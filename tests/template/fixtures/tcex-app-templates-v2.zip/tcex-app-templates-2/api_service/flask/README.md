# Release Notes

## 1.0.0 (2022-12-13)
* Initial Release

# Description
App template for a flask-based API service.

First steps:
- Define parameters in install.json
- Update inputs model in app_inputs.py
- Implement flask app in flask_app module.  A small example flask app is included.
- Implement get_wsgi_app() in app.py
